<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Asset Management System</title>
</head>
<body>
    <h1>Asset Management System</h1>

    <h2>Assignment 4</h2>
    <ul>
        <li><a href="retrieve_asset_by_location_zone.php">Retrieve Asset by Location Zone</a></li>
        <li><a href="retrieve_total_asset_count_in_warehouse.php">Retrieve Total Asset Count in Warehouse</a></li>
        <li><a href="show_movement_history_of_specific_asset.php">Show Movement History of a Specific Asset</a></li>
    </ul>
</body>
</html>
