<!DOCTYPE html>
<html lang="en">

<body>
    
    <ul>
        <li><a href="insert_asset.php">Insert Asset</a></li>
        <li><a href="insert_location.php">Insert Location</a></li>
        <li><a href="insert_movement.php">Insert Movement</a></li>
    </ul>

</body>
</html>
